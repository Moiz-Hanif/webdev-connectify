var myDiv = document.getElementById("myDiv");
var toggleButton = document.getElementById("Co");

toggleButton.addEventListener("click", function() {
  if (myDiv.style.display === "none" || myDiv.style.display === "") {
    myDiv.style.display = "block";
  } else {
    myDiv.style.display = "none";
  }
});
